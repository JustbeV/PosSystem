/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package possystem;

import com.possystem.user.Account;
import com.possystem.user.Checking;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class PosSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner sc=new Scanner(System.in);
//        String option;
//        String pin;
//        System.out.print("Enter your PIN to start:");
//        pin=sc.nextLine();
//        
//    
//        System.out.println(pin);
//        
//        System.out.println("No Account yet? Enter 1 to create");
//        do{
//            
//            
//        System.out.print("");
//        option=sc.nextLine();
//        
//            switch(option){
//                case "1":
//                    account();
//                    break;
//                case "2": 
//                    rewards();
//            }
//        }while(option != "0");
//           
//    
//    }
//
//    private static void account(){
//        
//            Scanner sc= new Scanner(System.in);
//                 
//                    
//         }
//
//    private static void rewards() {
//        
//       }
//
//    private static void menu() {
//        System.out.println("PIN\n");
//       }
//    public static String trimStr(String word, int len, String separator){
//            String res = word;
//            int i;
//            for(i = word.length(); i <= len; i++){
//                res += separator;
//            }
//            return res;
//        }
    }
}
